package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzary implements Creator<zzarx> {
    static void zza(zzarx zzarx, Parcel parcel, int i) {
        int zzaV = zzc.zzaV(parcel);
        zzc.zzc(parcel, 1, zzarx.zzbkr);
        zzc.zza(parcel, 2, zzarx.zzbks, i, false);
        zzc.zza(parcel, 3, zzarx.zzHD(), false);
        zzc.zza(parcel, 4, zzarx.mPendingIntent, i, false);
        zzc.zza(parcel, 5, zzarx.zzHE(), false);
        zzc.zza(parcel, 6, zzarx.zzHF(), false);
        zzc.zzc(parcel, 1000, zzarx.getVersionCode());
        zzc.zzJ(parcel, zzaV);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzgS(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzkr(i);
    }

    public zzarx zzgS(Parcel parcel) {
        zzarv zzarv = null;
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        int i2 = 1;
        IBinder iBinder = null;
        PendingIntent pendingIntent = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        while (parcel.dataPosition() < zzaU) {
            int zzaT = zzb.zzaT(parcel);
            switch (zzb.zzcW(zzaT)) {
                case 1:
                    i2 = zzb.zzg(parcel, zzaT);
                    break;
                case 2:
                    zzarv = (zzarv) zzb.zza(parcel, zzaT, zzarv.CREATOR);
                    break;
                case 3:
                    iBinder = zzb.zzr(parcel, zzaT);
                    break;
                case 4:
                    pendingIntent = (PendingIntent) zzb.zza(parcel, zzaT, PendingIntent.CREATOR);
                    break;
                case 5:
                    iBinder2 = zzb.zzr(parcel, zzaT);
                    break;
                case 6:
                    iBinder3 = zzb.zzr(parcel, zzaT);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaT);
                    break;
                default:
                    zzb.zzb(parcel, zzaT);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaU) {
            return new zzarx(i, i2, zzarv, iBinder, pendingIntent, iBinder2, iBinder3);
        }
        throw new zza("Overread allowed size end=" + zzaU, parcel);
    }

    public zzarx[] zzkr(int i) {
        return new zzarx[i];
    }
}
