package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzasa implements Creator<zzarz> {
    static void zza(zzarz zzarz, Parcel parcel, int i) {
        int zzaV = zzc.zzaV(parcel);
        zzc.zza(parcel, 1, zzarz.getRequestId(), false);
        zzc.zza(parcel, 2, zzarz.getExpirationTime());
        zzc.zza(parcel, 3, zzarz.zzHG());
        zzc.zza(parcel, 4, zzarz.getLatitude());
        zzc.zza(parcel, 5, zzarz.getLongitude());
        zzc.zza(parcel, 6, zzarz.getRadius());
        zzc.zzc(parcel, 7, zzarz.zzHH());
        zzc.zzc(parcel, 1000, zzarz.getVersionCode());
        zzc.zzc(parcel, 8, zzarz.zzHI());
        zzc.zzc(parcel, 9, zzarz.zzHJ());
        zzc.zzJ(parcel, zzaV);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzgT(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzku(i);
    }

    public zzarz zzgT(Parcel parcel) {
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        String str = null;
        int i2 = 0;
        short s = (short) 0;
        double d = 0.0d;
        double d2 = 0.0d;
        float f = 0.0f;
        long j = 0;
        int i3 = 0;
        int i4 = -1;
        while (parcel.dataPosition() < zzaU) {
            int zzaT = zzb.zzaT(parcel);
            switch (zzb.zzcW(zzaT)) {
                case 1:
                    str = zzb.zzq(parcel, zzaT);
                    break;
                case 2:
                    j = zzb.zzi(parcel, zzaT);
                    break;
                case 3:
                    s = zzb.zzf(parcel, zzaT);
                    break;
                case 4:
                    d = zzb.zzn(parcel, zzaT);
                    break;
                case 5:
                    d2 = zzb.zzn(parcel, zzaT);
                    break;
                case 6:
                    f = zzb.zzl(parcel, zzaT);
                    break;
                case 7:
                    i2 = zzb.zzg(parcel, zzaT);
                    break;
                case 8:
                    i3 = zzb.zzg(parcel, zzaT);
                    break;
                case 9:
                    i4 = zzb.zzg(parcel, zzaT);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaT);
                    break;
                default:
                    zzb.zzb(parcel, zzaT);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaU) {
            return new zzarz(i, str, i2, s, d, d2, f, j, i3, i4);
        }
        throw new zza("Overread allowed size end=" + zzaU, parcel);
    }

    public zzarz[] zzku(int i) {
        return new zzarz[i];
    }
}
