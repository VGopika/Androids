package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zzb;

public abstract class zzabr<A extends zzb, L> {
    private final zzaaz.zzb<L> zzaBz;

    public zzaaz.zzb<L> zzwp() {
        return this.zzaBz;
    }
}
