package com.google.android.gms.internal;

import com.google.android.gms.internal.zzb.zza;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.impl.cookie.DateUtils;

public class zzt implements zzf {
    protected static final boolean DEBUG = zzs.DEBUG;
    private static int zzam = 3000;
    private static int zzan = 4096;
    protected final zzy zzao;
    protected final zzu zzap;

    public zzt(zzy zzy) {
        this(zzy, new zzu(zzan));
    }

    public zzt(zzy zzy, zzu zzu) {
        this.zzao = zzy;
        this.zzap = zzu;
    }

    protected static Map<String, String> zza(Header[] headerArr) {
        Map<String, String> treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        for (int i = 0; i < headerArr.length; i++) {
            treeMap.put(headerArr[i].getName(), headerArr[i].getValue());
        }
        return treeMap;
    }

    private void zza(long j, zzk<?> zzk, byte[] bArr, StatusLine statusLine) {
        if (DEBUG || j > ((long) zzam)) {
            Integer valueOf = bArr != null ? Integer.valueOf(bArr.length) : "null";
            zzs.zzb("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", zzk, Long.valueOf(j), valueOf, Integer.valueOf(statusLine.getStatusCode()), Integer.valueOf(zzk.zzq().zzd()));
        }
    }

    private static void zza(String str, zzk<?> zzk, zzr zzr) throws zzr {
        zzo zzq = zzk.zzq();
        int zzp = zzk.zzp();
        try {
            zzq.zza(zzr);
            zzk.zzc(String.format("%s-retry [timeout=%s]", new Object[]{str, Integer.valueOf(zzp)}));
        } catch (zzr e) {
            zzk.zzc(String.format("%s-timeout-giveup [timeout=%s]", new Object[]{str, Integer.valueOf(zzp)}));
            throw e;
        }
    }

    private void zza(Map<String, String> map, zza zza) {
        if (zza != null) {
            if (zza.zza != null) {
                map.put("If-None-Match", zza.zza);
            }
            if (zza.zzc > 0) {
                map.put("If-Modified-Since", DateUtils.formatDate(new Date(zza.zzc)));
            }
        }
    }

    private byte[] zza(HttpEntity httpEntity) throws IOException, zzp {
        zzaa zzaa = new zzaa(this.zzap, (int) httpEntity.getContentLength());
        byte[] bArr = null;
        try {
            InputStream content = httpEntity.getContent();
            if (content == null) {
                throw new zzp();
            }
            bArr = this.zzap.zzb(1024);
            while (true) {
                int read = content.read(bArr);
                if (read == -1) {
                    break;
                }
                zzaa.write(bArr, 0, read);
            }
            byte[] toByteArray = zzaa.toByteArray();
            return toByteArray;
        } finally {
            try {
                httpEntity.consumeContent();
            } catch (IOException e) {
                zzs.zza("Error occured when calling consumingContent", new Object[0]);
            }
            this.zzap.zza(bArr);
            zzaa.close();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.zzi zza(com.google.android.gms.internal.zzk<?> r20) throws com.google.android.gms.internal.zzr {
        /*
        r19 = this;
        r16 = android.os.SystemClock.elapsedRealtime();
    L_0x0004:
        r3 = 0;
        r6 = java.util.Collections.emptyMap();
        r2 = new java.util.HashMap;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r2.<init>();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r4 = r20.zzh();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r0 = r19;
        r0.zza(r2, r4);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r0 = r19;
        r4 = r0.zzao;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r0 = r20;
        r14 = r4.zza(r0, r2);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x00e7 }
        r12 = r14.getStatusLine();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r4 = r12.getStatusCode();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r2 = r14.getAllHeaders();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r6 = zza(r2);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r2 = 304; // 0x130 float:4.26E-43 double:1.5E-321;
        if (r4 != r2) goto L_0x0064;
    L_0x0035:
        r2 = r20.zzh();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        if (r2 != 0) goto L_0x004b;
    L_0x003b:
        r3 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r4 = 304; // 0x130 float:4.26E-43 double:1.5E-321;
        r5 = 0;
        r7 = 1;
        r8 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r8 = r8 - r16;
        r3.<init>(r4, r5, r6, r7, r8);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
    L_0x004a:
        return r3;
    L_0x004b:
        r3 = r2.zzf;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r3.putAll(r6);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r7 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r8 = 304; // 0x130 float:4.26E-43 double:1.5E-321;
        r9 = r2.data;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r10 = r2.zzf;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r11 = 1;
        r2 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r12 = r2 - r16;
        r7.<init>(r8, r9, r10, r11, r12);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r3 = r7;
        goto L_0x004a;
    L_0x0064:
        r2 = r14.getEntity();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        if (r2 == 0) goto L_0x009f;
    L_0x006a:
        r2 = r14.getEntity();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        r0 = r19;
        r11 = r0.zza(r2);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
    L_0x0074:
        r2 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        r8 = r2 - r16;
        r7 = r19;
        r10 = r20;
        r7.zza(r8, r10, r11, r12);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        r2 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        if (r4 < r2) goto L_0x0089;
    L_0x0085:
        r2 = 299; // 0x12b float:4.19E-43 double:1.477E-321;
        if (r4 <= r2) goto L_0x00a3;
    L_0x0089:
        r2 = new java.io.IOException;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        r2.<init>();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        throw r2;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
    L_0x008f:
        r2 = move-exception;
        r2 = "socket";
        r3 = new com.google.android.gms.internal.zzq;
        r3.<init>();
        r0 = r20;
        zza(r2, r0, r3);
        goto L_0x0004;
    L_0x009f:
        r2 = 0;
        r11 = new byte[r2];	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x0147 }
        goto L_0x0074;
    L_0x00a3:
        r3 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        r7 = 0;
        r8 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        r8 = r8 - r16;
        r5 = r11;
        r3.<init>(r4, r5, r6, r7, r8);	 Catch:{ SocketTimeoutException -> 0x008f, ConnectTimeoutException -> 0x00b1, MalformedURLException -> 0x00c1, IOException -> 0x014c }
        goto L_0x004a;
    L_0x00b1:
        r2 = move-exception;
        r2 = "connection";
        r3 = new com.google.android.gms.internal.zzq;
        r3.<init>();
        r0 = r20;
        zza(r2, r0, r3);
        goto L_0x0004;
    L_0x00c1:
        r2 = move-exception;
        r3 = r2;
        r2 = r20.getUrl();
        r2 = java.lang.String.valueOf(r2);
        r4 = r2.length();
        if (r4 == 0) goto L_0x00de;
    L_0x00d1:
        r4 = "Bad URL ";
        r2 = r4.concat(r2);
    L_0x00d8:
        r4 = new java.lang.RuntimeException;
        r4.<init>(r2, r3);
        throw r4;
    L_0x00de:
        r2 = new java.lang.String;
        r4 = "Bad URL ";
        r2.<init>(r4);
        goto L_0x00d8;
    L_0x00e7:
        r2 = move-exception;
        r5 = 0;
        r18 = r3;
        r3 = r2;
        r2 = r18;
    L_0x00ee:
        if (r2 == 0) goto L_0x0134;
    L_0x00f0:
        r2 = r2.getStatusLine();
        r4 = r2.getStatusCode();
        r2 = "Unexpected response code %d for %s";
        r3 = 2;
        r3 = new java.lang.Object[r3];
        r7 = 0;
        r8 = java.lang.Integer.valueOf(r4);
        r3[r7] = r8;
        r7 = 1;
        r8 = r20.getUrl();
        r3[r7] = r8;
        com.google.android.gms.internal.zzs.zzc(r2, r3);
        if (r5 == 0) goto L_0x0140;
    L_0x0111:
        r3 = new com.google.android.gms.internal.zzi;
        r7 = 0;
        r8 = android.os.SystemClock.elapsedRealtime();
        r8 = r8 - r16;
        r3.<init>(r4, r5, r6, r7, r8);
        r2 = 401; // 0x191 float:5.62E-43 double:1.98E-321;
        if (r4 == r2) goto L_0x0125;
    L_0x0121:
        r2 = 403; // 0x193 float:5.65E-43 double:1.99E-321;
        if (r4 != r2) goto L_0x013a;
    L_0x0125:
        r2 = "auth";
        r4 = new com.google.android.gms.internal.zza;
        r4.<init>(r3);
        r0 = r20;
        zza(r2, r0, r4);
        goto L_0x0004;
    L_0x0134:
        r2 = new com.google.android.gms.internal.zzj;
        r2.<init>(r3);
        throw r2;
    L_0x013a:
        r2 = new com.google.android.gms.internal.zzp;
        r2.<init>(r3);
        throw r2;
    L_0x0140:
        r2 = new com.google.android.gms.internal.zzh;
        r3 = 0;
        r2.<init>(r3);
        throw r2;
    L_0x0147:
        r2 = move-exception;
        r5 = 0;
        r3 = r2;
        r2 = r14;
        goto L_0x00ee;
    L_0x014c:
        r2 = move-exception;
        r5 = r11;
        r3 = r2;
        r2 = r14;
        goto L_0x00ee;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzt.zza(com.google.android.gms.internal.zzk):com.google.android.gms.internal.zzi");
    }
}
