package com.google.android.gms.internal;

public class zzr extends Exception {
    private long zzA;
    public final zzi zzah;

    public zzr() {
        this.zzah = null;
    }

    public zzr(zzi zzi) {
        this.zzah = zzi;
    }

    public zzr(Throwable th) {
        super(th);
        this.zzah = null;
    }

    void zza(long j) {
        this.zzA = j;
    }
}
