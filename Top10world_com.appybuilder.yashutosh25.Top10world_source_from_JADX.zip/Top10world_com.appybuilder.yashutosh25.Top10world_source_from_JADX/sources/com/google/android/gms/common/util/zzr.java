package com.google.android.gms.common.util;

public class zzr {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int zza(byte[] r7, int r8, int r9, int r10) {
        /*
        r6 = 461845907; // 0x1b873593 float:2.2368498E-22 double:2.281821963E-315;
        r1 = 0;
        r5 = -862048943; // 0xffffffffcc9e2d51 float:-8.2930312E7 double:NaN;
        r0 = r9 & -4;
        r2 = r8 + r0;
        r0 = r10;
    L_0x000c:
        if (r8 >= r2) goto L_0x0041;
    L_0x000e:
        r3 = r7[r8];
        r3 = r3 & 255;
        r4 = r8 + 1;
        r4 = r7[r4];
        r4 = r4 & 255;
        r4 = r4 << 8;
        r3 = r3 | r4;
        r4 = r8 + 2;
        r4 = r7[r4];
        r4 = r4 & 255;
        r4 = r4 << 16;
        r3 = r3 | r4;
        r4 = r8 + 3;
        r4 = r7[r4];
        r4 = r4 << 24;
        r3 = r3 | r4;
        r3 = r3 * r5;
        r4 = r3 >>> 17;
        r3 = r3 << 15;
        r3 = r3 | r4;
        r3 = r3 * r6;
        r0 = r0 ^ r3;
        r3 = -430675100; // 0xffffffffe6546b64 float:-2.5078068E23 double:NaN;
        r4 = r0 >>> 19;
        r0 = r0 << 13;
        r0 = r0 | r4;
        r0 = r0 * 5;
        r0 = r0 + r3;
        r8 = r8 + 4;
        goto L_0x000c;
    L_0x0041:
        r3 = r9 & 3;
        switch(r3) {
            case 1: goto L_0x006a;
            case 2: goto L_0x0061;
            case 3: goto L_0x0059;
            default: goto L_0x0046;
        };
    L_0x0046:
        r0 = r0 ^ r9;
        r1 = r0 >>> 16;
        r0 = r0 ^ r1;
        r1 = -2048144789; // 0xffffffff85ebca6b float:-2.217365E-35 double:NaN;
        r0 = r0 * r1;
        r1 = r0 >>> 13;
        r0 = r0 ^ r1;
        r1 = -1028477387; // 0xffffffffc2b2ae35 float:-89.34025 double:NaN;
        r0 = r0 * r1;
        r1 = r0 >>> 16;
        r0 = r0 ^ r1;
        return r0;
    L_0x0059:
        r1 = r2 + 2;
        r1 = r7[r1];
        r1 = r1 & 255;
        r1 = r1 << 16;
    L_0x0061:
        r3 = r2 + 1;
        r3 = r7[r3];
        r3 = r3 & 255;
        r3 = r3 << 8;
        r1 = r1 | r3;
    L_0x006a:
        r2 = r7[r2];
        r2 = r2 & 255;
        r1 = r1 | r2;
        r1 = r1 * r5;
        r2 = r1 >>> 17;
        r1 = r1 << 15;
        r1 = r1 | r2;
        r1 = r1 * r6;
        r0 = r0 ^ r1;
        goto L_0x0046;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.util.zzr.zza(byte[], int, int, int):int");
    }
}
