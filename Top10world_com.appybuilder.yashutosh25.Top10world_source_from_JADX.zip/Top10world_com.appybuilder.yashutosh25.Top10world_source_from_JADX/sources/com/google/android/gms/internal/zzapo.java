package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zzapn.zzd;
import java.util.ArrayList;
import java.util.Collection;

public class zzapo {
    private final Collection<zzapn> zzAJ = new ArrayList();
    private final Collection<zzd> zzAK = new ArrayList();
    private final Collection<zzd> zzAL = new ArrayList();

    public static void initialize(Context context) {
        zzapr.zzCR().initialize(context);
    }

    public void zza(zzapn zzapn) {
        this.zzAJ.add(zzapn);
    }
}
