package com.google.android.gms.internal;

public class zzh extends zzr {
    public zzh(zzi zzi) {
        super(zzi);
    }

    public zzh(Throwable th) {
        super(th);
    }
}
