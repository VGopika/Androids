package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zzb;

public abstract class zzabe<A extends zzb, L> {
    private final zzaaz<L> zzaBG;

    public zzaaz.zzb<L> zzwp() {
        return this.zzaBG.zzwp();
    }

    public void zzwq() {
        this.zzaBG.clear();
    }
}
