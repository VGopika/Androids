package com.google.android.gms.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;

public interface zzzz extends ConnectionCallbacks {
    void zza(ConnectionResult connectionResult, Api<?> api, int i);
}
