package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.common.internal.zzaf;

public class zzayc implements Creator<zzayb> {
    static void zza(zzayb zzayb, Parcel parcel, int i) {
        int zzaV = zzc.zzaV(parcel);
        zzc.zzc(parcel, 1, zzayb.mVersionCode);
        zzc.zza(parcel, 2, zzayb.zzxA(), i, false);
        zzc.zza(parcel, 3, zzayb.zzOp(), i, false);
        zzc.zzJ(parcel, zzaV);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zziS(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzmN(i);
    }

    public zzayb zziS(Parcel parcel) {
        ConnectionResult connectionResult = null;
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        zzaf zzaf = null;
        while (parcel.dataPosition() < zzaU) {
            zzaf zzaf2;
            int zzg;
            ConnectionResult connectionResult2;
            int zzaT = zzb.zzaT(parcel);
            switch (zzb.zzcW(zzaT)) {
                case 1:
                    ConnectionResult connectionResult3 = connectionResult;
                    zzaf2 = zzaf;
                    zzg = zzb.zzg(parcel, zzaT);
                    connectionResult2 = connectionResult3;
                    break;
                case 2:
                    connectionResult2 = (ConnectionResult) zzb.zza(parcel, zzaT, ConnectionResult.CREATOR);
                    zzaf2 = zzaf;
                    zzg = i;
                    break;
                case 3:
                    zzg = i;
                    zzaf zzaf3 = (zzaf) zzb.zza(parcel, zzaT, zzaf.CREATOR);
                    connectionResult2 = connectionResult;
                    zzaf2 = zzaf3;
                    break;
                default:
                    zzb.zzb(parcel, zzaT);
                    connectionResult2 = connectionResult;
                    zzaf2 = zzaf;
                    zzg = i;
                    break;
            }
            i = zzg;
            zzaf = zzaf2;
            connectionResult = connectionResult2;
        }
        if (parcel.dataPosition() == zzaU) {
            return new zzayb(i, connectionResult, zzaf);
        }
        throw new zza("Overread allowed size end=" + zzaU, parcel);
    }

    public zzayb[] zzmN(int i) {
        return new zzayb[i];
    }
}
