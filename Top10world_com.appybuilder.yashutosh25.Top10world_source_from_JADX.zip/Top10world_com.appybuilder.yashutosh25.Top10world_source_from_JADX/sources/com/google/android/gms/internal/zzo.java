package com.google.android.gms.internal;

public interface zzo {
    void zza(zzr zzr) throws zzr;

    int zzc();

    int zzd();
}
