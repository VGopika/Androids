package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import com.google.android.gms.common.util.zzs;

public final class zzabt extends Drawable implements Callback {
    private int mFrom;
    private boolean zzaCZ;
    private int zzaDe;
    private int zzaDf;
    private int zzaDg;
    private int zzaDh;
    private int zzaDi;
    private boolean zzaDj;
    private zzb zzaDk;
    private Drawable zzaDl;
    private Drawable zzaDm;
    private boolean zzaDn;
    private boolean zzaDo;
    private boolean zzaDp;
    private int zzaDq;
    private long zzaed;

    private static final class zza extends Drawable {
        private static final zza zzaDr = new zza();
        private static final zza zzaDs = new zza();

        private static final class zza extends ConstantState {
            private zza() {
            }

            public int getChangingConfigurations() {
                return 0;
            }

            public Drawable newDrawable() {
                return zza.zzaDr;
            }
        }

        private zza() {
        }

        public void draw(Canvas canvas) {
        }

        public ConstantState getConstantState() {
            return zzaDs;
        }

        public int getOpacity() {
            return -2;
        }

        public void setAlpha(int i) {
        }

        public void setColorFilter(ColorFilter colorFilter) {
        }
    }

    static final class zzb extends ConstantState {
        int mChangingConfigurations;
        int zzaDt;

        zzb(zzb zzb) {
            if (zzb != null) {
                this.mChangingConfigurations = zzb.mChangingConfigurations;
                this.zzaDt = zzb.zzaDt;
            }
        }

        public int getChangingConfigurations() {
            return this.mChangingConfigurations;
        }

        public Drawable newDrawable() {
            return new zzabt(this);
        }
    }

    public zzabt(Drawable drawable, Drawable drawable2) {
        this(null);
        if (drawable == null) {
            drawable = zza.zzaDr;
        }
        this.zzaDl = drawable;
        drawable.setCallback(this);
        zzb zzb = this.zzaDk;
        zzb.zzaDt |= drawable.getChangingConfigurations();
        if (drawable2 == null) {
            drawable2 = zza.zzaDr;
        }
        this.zzaDm = drawable2;
        drawable2.setCallback(this);
        zzb = this.zzaDk;
        zzb.zzaDt |= drawable2.getChangingConfigurations();
    }

    zzabt(zzb zzb) {
        this.zzaDe = 0;
        this.zzaDg = 255;
        this.zzaDi = 0;
        this.zzaCZ = true;
        this.zzaDk = new zzb(zzb);
    }

    public boolean canConstantState() {
        if (!this.zzaDn) {
            boolean z = (this.zzaDl.getConstantState() == null || this.zzaDm.getConstantState() == null) ? false : true;
            this.zzaDo = z;
            this.zzaDn = true;
        }
        return this.zzaDo;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void draw(android.graphics.Canvas r8) {
        /*
        r7 = this;
        r1 = 1;
        r6 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r0 = 0;
        r2 = r7.zzaDe;
        switch(r2) {
            case 1: goto L_0x0028;
            case 2: goto L_0x0032;
            default: goto L_0x0009;
        };
    L_0x0009:
        r0 = r1;
    L_0x000a:
        r1 = r7.zzaDi;
        r2 = r7.zzaCZ;
        r3 = r7.zzaDl;
        r4 = r7.zzaDm;
        if (r0 == 0) goto L_0x0061;
    L_0x0014:
        if (r2 == 0) goto L_0x0018;
    L_0x0016:
        if (r1 != 0) goto L_0x001b;
    L_0x0018:
        r3.draw(r8);
    L_0x001b:
        r0 = r7.zzaDg;
        if (r1 != r0) goto L_0x0027;
    L_0x001f:
        r0 = r7.zzaDg;
        r4.setAlpha(r0);
        r4.draw(r8);
    L_0x0027:
        return;
    L_0x0028:
        r2 = android.os.SystemClock.uptimeMillis();
        r7.zzaed = r2;
        r1 = 2;
        r7.zzaDe = r1;
        goto L_0x000a;
    L_0x0032:
        r2 = r7.zzaed;
        r4 = 0;
        r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r2 < 0) goto L_0x0009;
    L_0x003a:
        r2 = android.os.SystemClock.uptimeMillis();
        r4 = r7.zzaed;
        r2 = r2 - r4;
        r2 = (float) r2;
        r3 = r7.zzaDh;
        r3 = (float) r3;
        r2 = r2 / r3;
        r3 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r3 < 0) goto L_0x005f;
    L_0x004a:
        if (r1 == 0) goto L_0x004e;
    L_0x004c:
        r7.zzaDe = r0;
    L_0x004e:
        r0 = java.lang.Math.min(r2, r6);
        r2 = r7.zzaDf;
        r2 = r2 + 0;
        r2 = (float) r2;
        r0 = r0 * r2;
        r2 = 0;
        r0 = r0 + r2;
        r0 = (int) r0;
        r7.zzaDi = r0;
        r0 = r1;
        goto L_0x000a;
    L_0x005f:
        r1 = r0;
        goto L_0x004a;
    L_0x0061:
        if (r2 == 0) goto L_0x0069;
    L_0x0063:
        r0 = r7.zzaDg;
        r0 = r0 - r1;
        r3.setAlpha(r0);
    L_0x0069:
        r3.draw(r8);
        if (r2 == 0) goto L_0x0073;
    L_0x006e:
        r0 = r7.zzaDg;
        r3.setAlpha(r0);
    L_0x0073:
        if (r1 <= 0) goto L_0x0080;
    L_0x0075:
        r4.setAlpha(r1);
        r4.draw(r8);
        r0 = r7.zzaDg;
        r4.setAlpha(r0);
    L_0x0080:
        r7.invalidateSelf();
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzabt.draw(android.graphics.Canvas):void");
    }

    public int getChangingConfigurations() {
        return (super.getChangingConfigurations() | this.zzaDk.mChangingConfigurations) | this.zzaDk.zzaDt;
    }

    public ConstantState getConstantState() {
        if (!canConstantState()) {
            return null;
        }
        this.zzaDk.mChangingConfigurations = getChangingConfigurations();
        return this.zzaDk;
    }

    public int getIntrinsicHeight() {
        return Math.max(this.zzaDl.getIntrinsicHeight(), this.zzaDm.getIntrinsicHeight());
    }

    public int getIntrinsicWidth() {
        return Math.max(this.zzaDl.getIntrinsicWidth(), this.zzaDm.getIntrinsicWidth());
    }

    public int getOpacity() {
        if (!this.zzaDp) {
            this.zzaDq = Drawable.resolveOpacity(this.zzaDl.getOpacity(), this.zzaDm.getOpacity());
            this.zzaDp = true;
        }
        return this.zzaDq;
    }

    @TargetApi(11)
    public void invalidateDrawable(Drawable drawable) {
        if (zzs.zzyx()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.invalidateDrawable(this);
            }
        }
    }

    public Drawable mutate() {
        if (!this.zzaDj && super.mutate() == this) {
            if (canConstantState()) {
                this.zzaDl.mutate();
                this.zzaDm.mutate();
                this.zzaDj = true;
            } else {
                throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated.");
            }
        }
        return this;
    }

    protected void onBoundsChange(Rect rect) {
        this.zzaDl.setBounds(rect);
        this.zzaDm.setBounds(rect);
    }

    @TargetApi(11)
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        if (zzs.zzyx()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.scheduleDrawable(this, runnable, j);
            }
        }
    }

    public void setAlpha(int i) {
        if (this.zzaDi == this.zzaDg) {
            this.zzaDi = i;
        }
        this.zzaDg = i;
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.zzaDl.setColorFilter(colorFilter);
        this.zzaDm.setColorFilter(colorFilter);
    }

    public void startTransition(int i) {
        this.mFrom = 0;
        this.zzaDf = this.zzaDg;
        this.zzaDi = 0;
        this.zzaDh = i;
        this.zzaDe = 1;
        invalidateSelf();
    }

    @TargetApi(11)
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        if (zzs.zzyx()) {
            Callback callback = getCallback();
            if (callback != null) {
                callback.unscheduleDrawable(this, runnable);
            }
        }
    }

    public Drawable zzwM() {
        return this.zzaDm;
    }
}
