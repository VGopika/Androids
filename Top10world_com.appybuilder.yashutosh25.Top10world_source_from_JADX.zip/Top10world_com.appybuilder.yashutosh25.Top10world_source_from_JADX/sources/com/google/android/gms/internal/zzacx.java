package com.google.android.gms.internal;

import android.content.Context;

public class zzacx {
    private static zzacx zzaHl = new zzacx();
    private zzacw zzaHk = null;

    public static zzacw zzaQ(Context context) {
        return zzaHl.zzaP(context);
    }

    public zzacw zzaP(Context context) {
        zzacw zzacw;
        synchronized (this) {
            if (this.zzaHk == null) {
                if (context.getApplicationContext() != null) {
                    context = context.getApplicationContext();
                }
                this.zzaHk = new zzacw(context);
            }
            zzacw = this.zzaHk;
        }
        return zzacw;
    }
}
