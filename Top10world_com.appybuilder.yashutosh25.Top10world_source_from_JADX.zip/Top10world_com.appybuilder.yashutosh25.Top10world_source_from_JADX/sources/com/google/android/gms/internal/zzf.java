package com.google.android.gms.internal;

public interface zzf {
    zzi zza(zzk<?> zzk) throws zzr;
}
