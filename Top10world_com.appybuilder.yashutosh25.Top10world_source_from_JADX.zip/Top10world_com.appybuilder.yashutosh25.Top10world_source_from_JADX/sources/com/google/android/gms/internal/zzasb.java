package com.google.android.gms.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

public interface zzasb<T extends IInterface> {
    void zzwV();

    T zzwW() throws DeadObjectException;
}
