package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzb;

public class zzzr implements zzabk {
    public Exception zzz(Status status) {
        return zzb.zzF(status);
    }
}
