package kawa;

public class Version {
    public static String getVersion() {
        return "1.11";
    }
}
