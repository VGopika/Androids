package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api.zzb;

public final class zzabf {
    public final zzabe<zzb, ?> zzayq;
    public final zzabr<zzb, ?> zzayr;

    public zzabf(@NonNull zzabe<zzb, ?> zzabe, @NonNull zzabr<zzb, ?> zzabr) {
        this.zzayq = zzabe;
        this.zzayr = zzabr;
    }
}
