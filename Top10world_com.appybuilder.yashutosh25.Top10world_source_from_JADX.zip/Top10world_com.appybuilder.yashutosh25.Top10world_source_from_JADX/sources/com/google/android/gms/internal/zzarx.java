package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.location.zzl;
import com.google.android.gms.location.zzm;

public class zzarx extends zza {
    public static final Creator<zzarx> CREATOR = new zzary();
    PendingIntent mPendingIntent;
    private final int mVersionCode;
    int zzbkr;
    zzarv zzbks;
    zzm zzbkt;
    zzl zzbku;
    zzarp zzbkv;

    zzarx(int i, int i2, zzarv zzarv, IBinder iBinder, PendingIntent pendingIntent, IBinder iBinder2, IBinder iBinder3) {
        zzarp zzarp = null;
        this.mVersionCode = i;
        this.zzbkr = i2;
        this.zzbks = zzarv;
        this.zzbkt = iBinder == null ? null : zzm.zza.zzde(iBinder);
        this.mPendingIntent = pendingIntent;
        this.zzbku = iBinder2 == null ? null : zzl.zza.zzdd(iBinder2);
        if (iBinder3 != null) {
            zzarp = zzarp.zza.zzdg(iBinder3);
        }
        this.zzbkv = zzarp;
    }

    public static zzarx zza(zzarv zzarv, PendingIntent pendingIntent, @Nullable zzarp zzarp) {
        return new zzarx(1, 1, zzarv, null, pendingIntent, null, zzarp != null ? zzarp.asBinder() : null);
    }

    public static zzarx zza(zzarv zzarv, zzl zzl, @Nullable zzarp zzarp) {
        return new zzarx(1, 1, zzarv, null, null, zzl.asBinder(), zzarp != null ? zzarp.asBinder() : null);
    }

    public static zzarx zza(zzarv zzarv, zzm zzm, @Nullable zzarp zzarp) {
        return new zzarx(1, 1, zzarv, zzm.asBinder(), null, null, zzarp != null ? zzarp.asBinder() : null);
    }

    public static zzarx zza(zzl zzl, @Nullable zzarp zzarp) {
        return new zzarx(1, 2, null, null, null, zzl.asBinder(), zzarp != null ? zzarp.asBinder() : null);
    }

    public static zzarx zza(zzm zzm, @Nullable zzarp zzarp) {
        return new zzarx(1, 2, null, zzm.asBinder(), null, null, zzarp != null ? zzarp.asBinder() : null);
    }

    public static zzarx zzb(PendingIntent pendingIntent, @Nullable zzarp zzarp) {
        return new zzarx(1, 2, null, null, pendingIntent, null, zzarp != null ? zzarp.asBinder() : null);
    }

    int getVersionCode() {
        return this.mVersionCode;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzary.zza(this, parcel, i);
    }

    IBinder zzHD() {
        return this.zzbkt == null ? null : this.zzbkt.asBinder();
    }

    IBinder zzHE() {
        return this.zzbku == null ? null : this.zzbku.asBinder();
    }

    IBinder zzHF() {
        return this.zzbkv == null ? null : this.zzbkv.asBinder();
    }
}
