package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.RemoteException;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzaaz.zzc;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.zzl;
import com.google.android.gms.location.zzm;
import java.util.HashMap;
import java.util.Map;

public class zzart {
    private final Context mContext;
    private final Map<com.google.android.gms.internal.zzaaz.zzb<LocationListener>, zzb> zzaVF = new HashMap();
    private final zzasb<zzarr> zzbjV;
    private ContentProviderClient zzbkg = null;
    private boolean zzbkh = false;
    private final Map<com.google.android.gms.internal.zzaaz.zzb<LocationCallback>, zza> zzbki = new HashMap();

    private static class zza extends com.google.android.gms.location.zzl.zza {
        private final zzaaz<LocationCallback> zzaBG;

        zza(zzaaz<LocationCallback> zzaaz) {
            this.zzaBG = zzaaz;
        }

        public void onLocationAvailability(final LocationAvailability locationAvailability) {
            this.zzaBG.zza(new zzc<LocationCallback>(this) {
                public void zza(LocationCallback locationCallback) {
                    locationCallback.onLocationAvailability(locationAvailability);
                }

                public /* synthetic */ void zzs(Object obj) {
                    zza((LocationCallback) obj);
                }

                public void zzvy() {
                }
            });
        }

        public void onLocationResult(final LocationResult locationResult) {
            this.zzaBG.zza(new zzc<LocationCallback>(this) {
                public void zza(LocationCallback locationCallback) {
                    locationCallback.onLocationResult(locationResult);
                }

                public /* synthetic */ void zzs(Object obj) {
                    zza((LocationCallback) obj);
                }

                public void zzvy() {
                }
            });
        }

        public void release() {
            synchronized (this) {
                this.zzaBG.clear();
            }
        }
    }

    private static class zzb extends com.google.android.gms.location.zzm.zza {
        private final zzaaz<LocationListener> zzaBG;

        zzb(zzaaz<LocationListener> zzaaz) {
            this.zzaBG = zzaaz;
        }

        public void onLocationChanged(final Location location) {
            synchronized (this) {
                this.zzaBG.zza(new zzc<LocationListener>(this) {
                    public void zza(LocationListener locationListener) {
                        locationListener.onLocationChanged(location);
                    }

                    public /* synthetic */ void zzs(Object obj) {
                        zza((LocationListener) obj);
                    }

                    public void zzvy() {
                    }
                });
            }
        }

        public void release() {
            synchronized (this) {
                this.zzaBG.clear();
            }
        }
    }

    public zzart(Context context, zzasb<zzarr> zzasb) {
        this.mContext = context;
        this.zzbjV = zzasb;
    }

    private zzb zzf(zzaaz<LocationListener> zzaaz) {
        zzb zzb;
        synchronized (this.zzaVF) {
            zzb = (zzb) this.zzaVF.get(zzaaz.zzwp());
            if (zzb == null) {
                zzb = new zzb(zzaaz);
            }
            this.zzaVF.put(zzaaz.zzwp(), zzb);
        }
        return zzb;
    }

    private zza zzg(zzaaz<LocationCallback> zzaaz) {
        zza zza;
        synchronized (this.zzbki) {
            zza = (zza) this.zzbki.get(zzaaz.zzwp());
            if (zza == null) {
                zza = new zza(zzaaz);
            }
            this.zzbki.put(zzaaz.zzwp(), zza);
        }
        return zza;
    }

    public Location getLastLocation() {
        this.zzbjV.zzwV();
        try {
            return ((zzarr) this.zzbjV.zzwW()).zzeV(this.mContext.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeAllListeners() {
        try {
            synchronized (this.zzaVF) {
                for (zzm zzm : this.zzaVF.values()) {
                    if (zzm != null) {
                        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzm, null));
                    }
                }
                this.zzaVF.clear();
            }
            synchronized (this.zzbki) {
                for (zzl zzl : this.zzbki.values()) {
                    if (zzl != null) {
                        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzl, null));
                    }
                }
                this.zzbki.clear();
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public LocationAvailability zzHB() {
        this.zzbjV.zzwV();
        try {
            return ((zzarr) this.zzbjV.zzwW()).zzeW(this.mContext.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void zzHC() {
        if (this.zzbkh) {
            try {
                zzaC(false);
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public void zza(PendingIntent pendingIntent, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zzb(pendingIntent, zzarp));
    }

    public void zza(com.google.android.gms.internal.zzaaz.zzb<LocationListener> zzb, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        zzac.zzb((Object) zzb, (Object) "Invalid null listener key");
        synchronized (this.zzaVF) {
            zzm zzm = (zzb) this.zzaVF.remove(zzb);
            if (zzm != null) {
                zzm.release();
                ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzm, zzarp));
            }
        }
    }

    public void zza(zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zza(zzarp);
    }

    public void zza(zzarv zzarv, zzaaz<LocationCallback> zzaaz, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzarv, zzg(zzaaz), zzarp));
    }

    public void zza(LocationRequest locationRequest, PendingIntent pendingIntent, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzarv.zzb(locationRequest), pendingIntent, zzarp));
    }

    public void zza(LocationRequest locationRequest, zzaaz<LocationListener> zzaaz, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzarv.zzb(locationRequest), zzf(zzaaz), zzarp));
    }

    public void zzaC(boolean z) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zzaC(z);
        this.zzbkh = z;
    }

    public void zzb(com.google.android.gms.internal.zzaaz.zzb<LocationCallback> zzb, zzarp zzarp) throws RemoteException {
        this.zzbjV.zzwV();
        zzac.zzb((Object) zzb, (Object) "Invalid null listener key");
        synchronized (this.zzbki) {
            zzl zzl = (zza) this.zzbki.remove(zzb);
            if (zzl != null) {
                zzl.release();
                ((zzarr) this.zzbjV.zzwW()).zza(zzarx.zza(zzl, zzarp));
            }
        }
    }

    public void zzd(Location location) throws RemoteException {
        this.zzbjV.zzwV();
        ((zzarr) this.zzbjV.zzwW()).zzd(location);
    }
}
