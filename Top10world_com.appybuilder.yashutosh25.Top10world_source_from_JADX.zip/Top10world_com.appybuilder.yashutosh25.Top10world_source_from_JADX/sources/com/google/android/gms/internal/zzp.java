package com.google.android.gms.internal;

public class zzp extends zzr {
    public zzp(zzi zzi) {
        super(zzi);
    }
}
