package com.google.android.gms.internal;

import com.google.android.gms.common.api.zzc;

public class zzabd {
    public final zzzq zzaBD;
    public final int zzaBE;
    public final zzc<?> zzaBF;

    public zzabd(zzzq zzzq, int i, zzc<?> zzc) {
        this.zzaBD = zzzq;
        this.zzaBE = i;
        this.zzaBF = zzc;
    }
}
