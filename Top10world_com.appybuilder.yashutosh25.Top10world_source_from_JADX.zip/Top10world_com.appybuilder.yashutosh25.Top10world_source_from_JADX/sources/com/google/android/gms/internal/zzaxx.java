package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzaxx implements Creator<zzaxw> {
    static void zza(zzaxw zzaxw, Parcel parcel, int i) {
        int zzaV = zzc.zzaV(parcel);
        zzc.zzc(parcel, 1, zzaxw.mVersionCode);
        zzc.zza(parcel, 2, zzaxw.getAccount(), i, false);
        zzc.zza(parcel, 3, zzaxw.zzOm(), i, false);
        zzc.zza(parcel, 4, zzaxw.zzqN(), false);
        zzc.zzJ(parcel, zzaV);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zziQ(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzmL(i);
    }

    public zzaxw zziQ(Parcel parcel) {
        Scope[] scopeArr = null;
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        Account account = null;
        String str = null;
        while (parcel.dataPosition() < zzaU) {
            Scope[] scopeArr2;
            String str2;
            int zzg;
            Account account2;
            int zzaT = zzb.zzaT(parcel);
            Account account3;
            switch (zzb.zzcW(zzaT)) {
                case 1:
                    account3 = account;
                    scopeArr2 = scopeArr;
                    str2 = str;
                    zzg = zzb.zzg(parcel, zzaT);
                    account2 = account3;
                    break;
                case 2:
                    account2 = (Account) zzb.zza(parcel, zzaT, Account.CREATOR);
                    scopeArr2 = scopeArr;
                    str2 = str;
                    zzg = i;
                    break;
                case 3:
                    str2 = str;
                    zzg = i;
                    account3 = account;
                    scopeArr2 = (Scope[]) zzb.zzb(parcel, zzaT, Scope.CREATOR);
                    account2 = account3;
                    break;
                case 4:
                    zzg = i;
                    Scope[] scopeArr3 = scopeArr;
                    str2 = zzb.zzq(parcel, zzaT);
                    account2 = account;
                    scopeArr2 = scopeArr3;
                    break;
                default:
                    zzb.zzb(parcel, zzaT);
                    account2 = account;
                    scopeArr2 = scopeArr;
                    str2 = str;
                    zzg = i;
                    break;
            }
            i = zzg;
            str = str2;
            scopeArr = scopeArr2;
            account = account2;
        }
        if (parcel.dataPosition() == zzaU) {
            return new zzaxw(i, account, scopeArr, str);
        }
        throw new zza("Overread allowed size end=" + zzaU, parcel);
    }

    public zzaxw[] zzmL(int i) {
        return new zzaxw[i];
    }
}
