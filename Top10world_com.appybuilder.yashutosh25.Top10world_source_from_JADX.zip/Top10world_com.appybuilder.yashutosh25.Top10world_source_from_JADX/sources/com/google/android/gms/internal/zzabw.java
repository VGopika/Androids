package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzacc.zza;

public class zzabw extends zza {
    public void zzcX(int i) throws RemoteException {
    }
}
