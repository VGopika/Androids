package com.google.android.gms.internal;

public class zza extends zzr {
    public zza(zzi zzi) {
        super(zzi);
    }

    public String getMessage() {
        return super.getMessage();
    }
}
