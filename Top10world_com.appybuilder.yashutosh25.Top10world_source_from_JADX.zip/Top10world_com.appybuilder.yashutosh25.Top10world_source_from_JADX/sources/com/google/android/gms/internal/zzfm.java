package com.google.android.gms.internal;

import com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks;
import com.google.android.gms.internal.zzex.zza;

public final class zzfm extends zza {
    private final VideoLifecycleCallbacks zzrP;

    public zzfm(VideoLifecycleCallbacks videoLifecycleCallbacks) {
        this.zzrP = videoLifecycleCallbacks;
    }

    public void onVideoEnd() {
        this.zzrP.onVideoEnd();
    }

    public void zzeT() {
    }

    public void zzeU() {
    }

    public void zzeV() {
    }
}
