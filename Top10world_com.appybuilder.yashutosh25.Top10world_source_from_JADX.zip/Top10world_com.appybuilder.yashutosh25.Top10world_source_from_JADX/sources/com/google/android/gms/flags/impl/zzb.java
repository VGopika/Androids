package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.zzaps;
import java.util.concurrent.Callable;

public class zzb {
    private static SharedPreferences zzaWS = null;

    /* renamed from: com.google.android.gms.flags.impl.zzb$1 */
    final class C09011 implements Callable<SharedPreferences> {
        final /* synthetic */ Context zztd;

        C09011(Context context) {
            this.zztd = context;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzCU();
        }

        public SharedPreferences zzCU() {
            return this.zztd.getSharedPreferences("google_sdk_flags", 1);
        }
    }

    public static SharedPreferences zzm(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            try {
                if (zzaWS == null) {
                    zzaWS = (SharedPreferences) zzaps.zzb(new C09011(context));
                }
                sharedPreferences = zzaWS;
            } catch (Throwable th) {
                Class cls = SharedPreferences.class;
            }
        }
        return sharedPreferences;
    }
}
