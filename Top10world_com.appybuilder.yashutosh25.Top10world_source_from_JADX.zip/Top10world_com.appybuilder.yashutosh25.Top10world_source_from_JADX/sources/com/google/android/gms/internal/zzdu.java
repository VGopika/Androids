package com.google.android.gms.internal;

import com.google.android.gms.internal.zzek.zza;

@zzmb
public final class zzdu extends zza {
    private final zzdt zzyD;

    public zzdu(zzdt zzdt) {
        this.zzyD = zzdt;
    }

    public void onAdClicked() {
        this.zzyD.onAdClicked();
    }
}
