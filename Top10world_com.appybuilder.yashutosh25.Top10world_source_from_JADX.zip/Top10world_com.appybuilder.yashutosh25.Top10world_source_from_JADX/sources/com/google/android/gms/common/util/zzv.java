package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public class zzv {
    private static final Pattern zzaHb = Pattern.compile("\\$\\{(.*?)\\}");

    public static boolean zzdD(String str) {
        return str == null || str.trim().isEmpty();
    }
}
