package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzhb.zza;

public class zzfh extends zza {
    public void destroy() throws RemoteException {
    }

    public zzd zzU(String str) throws RemoteException {
        return null;
    }

    public void zzc(String str, zzd zzd) throws RemoteException {
    }

    public void zze(zzd zzd) throws RemoteException {
    }
}
