package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.zzaxu.zza;

public class zzaxr extends zza {
    public void zza(ConnectionResult connectionResult, zzaxp zzaxp) throws RemoteException {
    }

    public void zza(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public void zzb(zzayb zzayb) throws RemoteException {
    }

    public void zzbI(Status status) throws RemoteException {
    }

    public void zzbJ(Status status) throws RemoteException {
    }
}
