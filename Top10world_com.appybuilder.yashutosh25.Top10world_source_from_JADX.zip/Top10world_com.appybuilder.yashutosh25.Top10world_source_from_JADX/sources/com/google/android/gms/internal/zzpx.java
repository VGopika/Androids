package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri.Builder;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.Secure;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.TextView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.doubleclick.PublisherInterstitialAd;
import com.google.android.gms.ads.search.SearchAdView;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.common.zzc;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.StringTokenizer;
import org.shaded.apache.http.protocol.HTTP;

@zzmb
public class zzpx {
    public static final Handler zzXU = new Handler(Looper.getMainLooper());
    private static final String zzXV = AdView.class.getName();
    private static final String zzXW = InterstitialAd.class.getName();
    private static final String zzXX = PublisherAdView.class.getName();
    private static final String zzXY = PublisherInterstitialAd.class.getName();
    private static final String zzXZ = SearchAdView.class.getName();
    private static final String zzYa = AdLoader.class.getName();

    public interface zza {
        void zzu(String str);
    }

    /* renamed from: com.google.android.gms.internal.zzpx$1 */
    class C09951 implements zza {
        C09951(zzpx zzpx) {
        }

        public void zzu(final String str) {
            new Thread(this) {
                public void run() {
                    new zzpz().zzu(str);
                }
            }.start();
        }
    }

    private void zza(ViewGroup viewGroup, zzec zzec, String str, int i, int i2) {
        if (viewGroup.getChildCount() == 0) {
            Context context = viewGroup.getContext();
            View textView = new TextView(context);
            textView.setGravity(17);
            textView.setText(str);
            textView.setTextColor(i);
            textView.setBackgroundColor(i2);
            View frameLayout = new FrameLayout(context);
            frameLayout.setBackgroundColor(i);
            int zzb = zzb(context, 3);
            frameLayout.addView(textView, new LayoutParams(zzec.widthPixels - zzb, zzec.heightPixels - zzb, 17));
            viewGroup.addView(frameLayout, zzec.widthPixels, zzec.heightPixels);
        }
    }

    public String zzO(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        String string = contentResolver == null ? null : Secure.getString(contentResolver, "android_id");
        if (string == null || zzkI()) {
            string = "emulator";
        }
        return zzbb(string);
    }

    public boolean zzP(Context context) {
        return zzc.zzuz().isGooglePlayServicesAvailable(context) == 0;
    }

    public boolean zzQ(Context context) {
        if (context.getResources().getConfiguration().orientation == 2) {
            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            if (((int) (((float) displayMetrics.heightPixels) / displayMetrics.density)) < 600) {
                return true;
            }
        }
        return false;
    }

    @TargetApi(17)
    public boolean zzR(Context context) {
        int i;
        int i2;
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        if (zzs.zzyD()) {
            defaultDisplay.getRealMetrics(displayMetrics);
            i = displayMetrics.heightPixels;
            i2 = displayMetrics.widthPixels;
        } else {
            try {
                int intValue = ((Integer) Display.class.getMethod("getRawHeight", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                i2 = ((Integer) Display.class.getMethod("getRawWidth", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                i = intValue;
            } catch (Exception e) {
                return false;
            }
        }
        defaultDisplay.getMetrics(displayMetrics);
        return displayMetrics.heightPixels == i && displayMetrics.widthPixels == i2;
    }

    public int zzS(Context context) {
        int identifier = context.getResources().getIdentifier("navigation_bar_width", "dimen", "android");
        return identifier > 0 ? context.getResources().getDimensionPixelSize(identifier) : 0;
    }

    public int zza(DisplayMetrics displayMetrics, int i) {
        return (int) TypedValue.applyDimension(1, (float) i, displayMetrics);
    }

    @Nullable
    public String zza(StackTraceElement[] stackTraceElementArr, String str) {
        String className;
        for (int i = 0; i + 1 < stackTraceElementArr.length; i++) {
            StackTraceElement stackTraceElement = stackTraceElementArr[i];
            String className2 = stackTraceElement.getClassName();
            if ("loadAd".equalsIgnoreCase(stackTraceElement.getMethodName()) && (zzXV.equalsIgnoreCase(className2) || zzXW.equalsIgnoreCase(className2) || zzXX.equalsIgnoreCase(className2) || zzXY.equalsIgnoreCase(className2) || zzXZ.equalsIgnoreCase(className2) || zzYa.equalsIgnoreCase(className2))) {
                className = stackTraceElementArr[i + 1].getClassName();
                break;
            }
        }
        className = null;
        if (str != null) {
            CharSequence zzb = zzb(str, ".", 3);
            if (!(className == null || className.contains(zzb))) {
                return className;
            }
        }
        return null;
    }

    public void zza(Context context, @Nullable String str, String str2, Bundle bundle, boolean z) {
        zza(context, str, str2, bundle, z, new C09951(this));
    }

    public void zza(Context context, @Nullable String str, String str2, Bundle bundle, boolean z, zza zza) {
        if (z) {
            Context applicationContext = context.getApplicationContext();
            if (applicationContext == null) {
                applicationContext = context;
            }
            bundle.putString("os", VERSION.RELEASE);
            bundle.putString("api", String.valueOf(VERSION.SDK_INT));
            bundle.putString("appid", applicationContext.getPackageName());
            if (str == null) {
                str = zzc.zzuz().zzak(context) + "." + 10084000;
            }
            bundle.putString("js", str);
        }
        Builder appendQueryParameter = new Builder().scheme("https").path("//pagead2.googlesyndication.com/pagead/gen_204").appendQueryParameter("id", str2);
        for (String str3 : bundle.keySet()) {
            appendQueryParameter.appendQueryParameter(str3, bundle.getString(str3));
        }
        zza.zzu(appendQueryParameter.toString());
    }

    public void zza(ViewGroup viewGroup, zzec zzec, String str) {
        zza(viewGroup, zzec, str, -16777216, -1);
    }

    public void zza(ViewGroup viewGroup, zzec zzec, String str, String str2) {
        zzpy.zzbe(str2);
        zza(viewGroup, zzec, str, -65536, -16777216);
    }

    public void zza(boolean z, HttpURLConnection httpURLConnection, @Nullable String str) {
        httpURLConnection.setConnectTimeout(60000);
        httpURLConnection.setInstanceFollowRedirects(z);
        httpURLConnection.setReadTimeout(60000);
        if (str != null) {
            httpURLConnection.setRequestProperty(HTTP.USER_AGENT, str);
        }
        httpURLConnection.setUseCaches(false);
    }

    public int zzb(Context context, int i) {
        return zza(context.getResources().getDisplayMetrics(), i);
    }

    public int zzb(DisplayMetrics displayMetrics, int i) {
        return Math.round(((float) i) / displayMetrics.density);
    }

    String zzb(String str, String str2, int i) {
        StringTokenizer stringTokenizer = new StringTokenizer(str, str2);
        StringBuilder stringBuilder = new StringBuilder();
        if (i <= 0 || !stringTokenizer.hasMoreElements()) {
            return str;
        }
        stringBuilder.append(stringTokenizer.nextToken());
        for (int i2 = i - 1; i2 > 0 && stringTokenizer.hasMoreElements(); i2--) {
            stringBuilder.append(".").append(stringTokenizer.nextToken());
        }
        return stringBuilder.toString();
    }

    public String zzbb(String str) {
        int i = 0;
        while (i < 2) {
            try {
                MessageDigest.getInstance("MD5").update(str.getBytes());
                return String.format(Locale.US, "%032X", new Object[]{new BigInteger(1, r1.digest())});
            } catch (NoSuchAlgorithmException e) {
                i++;
            }
        }
        return null;
    }

    public int zzc(Context context, int i) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        return zzb(displayMetrics, i);
    }

    public boolean zzkI() {
        return Build.DEVICE.startsWith("generic");
    }

    public boolean zzkJ() {
        return Looper.myLooper() == Looper.getMainLooper();
    }
}
