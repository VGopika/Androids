package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzeu.zza;

public class zzfg extends zza {
    public void initialize() throws RemoteException {
    }

    public void setAppMuted(boolean z) throws RemoteException {
    }

    public void setAppVolume(float f) throws RemoteException {
    }

    public void zzb(zzd zzd, String str) throws RemoteException {
    }

    public void zzy(String str) throws RemoteException {
    }
}
