package com.google.android.gms.internal;

public class zzq extends zzr {
}
